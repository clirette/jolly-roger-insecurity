<?hh

header('Location: /index.php');
